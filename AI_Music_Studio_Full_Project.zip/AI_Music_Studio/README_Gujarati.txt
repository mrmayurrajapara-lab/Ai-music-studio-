AI MUSIC STUDIO PROJECT
Run:
pip install -r requirements.txt
export ACESTEP_API_URL=https://YOUR-ACE-STEP-SERVER
export ACESTEP_API_KEY=  # only if your ACE-Step server uses a key
uvicorn main:app --host 0.0.0.0 --port 8000

Connects to ACE-Step 1.5 API: POST /release_task, POST /query_result, GET /v1/audio.
Docs: https://ace-step.github.io/ACE-Step-1.5/en/API

IMPORTANT: This project contains frontend and backend integration, NOT the large AI model. A separate GPU-capable ACE-Step server must be running. Free always-on GPU hosting is not guaranteed. Keep API keys on server only.
