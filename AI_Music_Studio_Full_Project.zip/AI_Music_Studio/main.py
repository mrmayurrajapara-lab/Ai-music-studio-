import os,json,asyncio
import httpx
from fastapi import FastAPI,HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import Response
from pydantic import BaseModel,Field
ACE=os.getenv("ACESTEP_API_URL","").rstrip("/")
KEY=os.getenv("ACESTEP_API_KEY","")
app=FastAPI(title="AI Music Studio")
class Req(BaseModel):
 prompt:str=""
 lyrics:str=""
 style:str="Hindi Romantic Lo-Fi"
 voice:str="vocal"
 language:str="hi"
 duration:int=Field(180,ge=10,le=600)
def hdr():
 h={"Content-Type":"application/json"}
 if KEY:h["Authorization"]="Bearer "+KEY
 return h
@app.get("/api/health")
async def health(): return {"ok":bool(ACE),"provider":"ACE-Step" if ACE else "not configured"}
@app.post("/api/generate")
async def generate(x:Req):
 if not ACE: raise HTTPException(503,"ACE-Step server હજી જોડાયેલો નથી. ACESTEP_API_URL સેટ કરવો પડશે.")
 if not x.prompt.strip() and not x.lyrics.strip(): raise HTTPException(400,"Prompt અથવા Lyrics લખો.")
 p=x.prompt+"; "+x.style+(", instrumental, no vocals" if x.voice=="instrumental" else ", song with vocals")
 payload={"prompt":p,"lyrics":x.lyrics,"vocal_language":x.language,"audio_format":"mp3","audio_duration":x.duration,"task_type":"text2music","thinking":True,"use_cot_caption":True,"use_cot_language":True,"model":"acestep-v15-turbo","inference_steps":8,"batch_size":1}
 async with httpx.AsyncClient(timeout=60) as c:
  try:
   r=await c.post(ACE+"/release_task",json=payload,headers=hdr());r.raise_for_status();tid=(r.json().get("data") or {}).get("task_id")
   if not tid: raise ValueError("No task ID returned")
   for _ in range(180):
    await asyncio.sleep(5);q=await c.post(ACE+"/query_result",json={"task_id_list":[tid]},headers=hdr());q.raise_for_status();items=q.json().get("data") or [];item=items[0] if items else {}
    if item.get("status")==2: raise HTTPException(502,"Music generation failed on model server.")
    if item.get("status")==1:
     result=item.get("result","[]");result=json.loads(result) if isinstance(result,str) else result;path=result[0].get("file","")
     if not path.startswith("/v1/audio"): raise HTTPException(502,"Audio file not returned.")
     return {"audio_url":"/api/audio?path="+httpx.QueryParams({"path":path})["path"]}
  except HTTPException: raise
  except Exception as e: raise HTTPException(502,"ACE-Step API error: "+str(e))
 raise HTTPException(504,"Generation timed out.")
@app.get("/api/audio")
async def audio(path:str):
 if not ACE or not path.startswith("/v1/audio"): raise HTTPException(400,"Invalid audio path.")
 async with httpx.AsyncClient(timeout=120) as c:
  try:
   r=await c.get(ACE+path,headers=hdr());r.raise_for_status()
   return Response(r.content,media_type=r.headers.get("content-type","audio/mpeg"),headers={"Content-Disposition":'attachment; filename="ai-music-studio.mp3"'})
  except Exception as e: raise HTTPException(502,"Audio download failed: "+str(e))
app.mount("/",StaticFiles(directory="static",html=True),name="static")
